from pymongo import MongoClient


def secret_key():
    key = 'THIS_IS_COFFEE'
    return key


def db_connect():
    client = MongoClient('15.164.169.178', 27017, username="test", password="test")
    return client.today_coffee
