# 오늘의 커피

스타벅스 메뉴 중에서 가장 맛있는 메뉴를 추천해주는 사이트

### 주요 기능
- 추천이 많은 순으로 커피 메뉴 표시
- 메뉴에 대한 좋아요, 싫어요 기능
- 회원가입 및 로그인 기능 (JWT 활용)
- 댓글 리뷰 등록 및 확인

### 사용 기술
Python, Flask, MongoDB, JWT, JS

### 주요 페이지
![스크린샷 2021-03-04 오전 9 38 38](https://user-images.githubusercontent.com/58046372/109893255-aba8b680-7cce-11eb-9659-60eeecafaf5b.png)
![스크린샷 2021-03-04 오전 9 41 09](https://user-images.githubusercontent.com/58046372/109893302-bf541d00-7cce-11eb-9ed0-4810de9edcdc.png)
